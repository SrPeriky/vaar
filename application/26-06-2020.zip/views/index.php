<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Login</title>

  <!-- Custom fonts for this template-->

  <!-- Custom styles for this template-->
  <link href="<?php echo base_url(); ?>assets/css/sb-admin-2.min.css" rel="stylesheet">

   <!-- Custom styles for this page -->

</head>

<body class="bg-info">
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Bienvenido!</h1>
                  </div>
                  <form  class="user" method="post" action="<?php echo base_url() ?>Zd/registrar">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" name="nombre" placeholder="Ingresa tu avatar...">
                    </div> 
                    <button class="btn btn-primary btn-user btn-block" type="submit">Jugar!</button>
                  </form>
                  <hr>
                  <div class="text-center">
                    <i class="small">El "avatar" que ingreses no debe contener espacios, tampoco se debe dejar en blanco.. ingresa solo una palabra.. esto ayuará a identificarte a la hora de jugar</i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  
   <!-- Optional JavaScript -->

  <!-- Bootstrap core JavaScript -->

  <!-- Plugin JavaScript -->

  <!-- Contact Form JavaScript -->
  <!-- Custom scripts for this template -->
</html>
