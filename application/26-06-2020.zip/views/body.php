<body class="bg-info">
  <div class="container">
    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="card card-body  o-hidden border-0 shadow-lg my-2">
          <div class="text-center small text-gray-500">
            Bienvenido jugaor <?php echo $player; ?> <i id="lulopo">[ X V.S O] </i> 
          </div>
          <div class="p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 d-lg-block p-3">
                <div id="x">
                </div>
                <div class="col-12 ">
                  <input type="text" class="cuadrito" value="" id="1" readonly onclick="marcar(this.id)">
                  <input type="text" class="cuadrito" value="" id="2" readonly onclick="marcar(this.id)">
                  <input type="text" class="cuadrito" value="" id="3" readonly onclick="marcar(this.id)">
                </div>
                <div class="col-12">
                  <input type="text" class="cuadrito" value="" id="4" readonly onclick="marcar(this.id)">
                  <input type="text" class="cuadrito" value="" id="5" readonly onclick="marcar(this.id)">
                  <input type="text" class="cuadrito" value="" id="6" readonly onclick="marcar(this.id)">
                </div>
                <div class="col-12">
                  <input type="text" class="cuadrito" value="" id="7" readonly onclick="marcar(this.id)">
                  <input type="text" class="cuadrito" value="" id="8" readonly onclick="marcar(this.id)">
                  <input type="text" class="cuadrito" value="" id="9" readonly onclick="marcar(this.id)">
                </div>
                </div>
                <div id="turno" class="col-lg-6 d-my-0">
                  <div class="alert text-center alert-dark" role="alert">cargando...</div>
                </div> 
                <a href="http://nwnw.000webhostapp.com/Zd/salir#" role="button" class="btn btn-success btn-block">abandonar la partida</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id=""></div>