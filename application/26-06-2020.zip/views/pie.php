 
   <!-- Optional JavaScript -->

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php echo base_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="<?php echo base_url(); ?>assets/js/jqBootstrapValidation.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/contact_me.js"></script>
  
  <script src="<?php echo base_url(); ?>assets/gato/ganar.js"></script>

  <script type="text/javascript">
    var gato = 8;
    var con = 0;
    var user = '<?php echo $usuario; ?>';
    function marcar(id)
    { 
      if (con!=1) {
        if (gato==1)
          {gato=8;
        document.getElementById('x').innerHTML='';
        $iddd = id;
            $.ajax(
            {
              type: "POST",
              data: "user=<?php echo $usuario;?>&cubo="+id+"&sala=<?php echo $sala; ?>",
              url: '<?php echo base_url();?>Zd/gatoUpp',
              dataType: "json",
              cache: false,
              success: function(data)
              {
                  var turno = data.turno;
                  ppp($iddd, turno);
              }
            });
          }
           else 
      {
            document.getElementById('x').innerHTML='<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
              '<strong>Hey @<?php echo $titulo; ?>..!!</strong> Aún no es tú turno.'+
              '<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
              '<span aria-hidden="true">&times;</span>'+
              '</button>'+
            '</div>';
      }
      }
    }

   
  function recargarVentanaGato()
    {
      
        setInterval(function()
        {
          if (con!=1)
          {
            $.ajax({
              type: "POST",
              dataType: "json",
              url: '<?php echo base_url();?>Zd/gato_canal',
              cache: false,
              data: "sala=<?php echo $sala;?>",
              success: function(data){
                $.each(data,function(index,value) {
                  var turno = data[index].turno;
                    if (data[index].o == '' || data[index].o == null) 
                    {
                      document.getElementById("turno").innerHTML='<div class="alert alert-danger " role="alert">esperando al jugador O...</div>';
                      document.getElementById("lulopo").innerHTML='[ '+data[index].x+' V.S (esperando...)]';
                    } else if (turno==0) {
                        
                        document.getElementById("lulopo").innerHTML='[ <?php echo $jugadorX; ?> V.S '+data[index].o+' ]';
                    
                    document.getElementById("turno").innerHTML='<div class="alert alert-success " role="alert">Turno del jugador : O!</div>';} 
                    
                    else if (turno==1) {document.getElementById("lulopo").innerHTML='[ <?php echo $jugadorX; ?> V.S '+data[index].o+' ]';document.getElementById("turno").innerHTML='<div class="alert alert-primary" role="alert">Turno del jugador : X!</div>';} 
                  if (turno==<?php echo $usuario; ?>) {gato=1;document.getElementById('x').innerHTML='';  } else {gato=0}
                  if (turno==0) {
                    ppp(data[index].cuboY, turno)
                  } else {ppp(data[index].cuboX, turno)}
                });
              }
            });
          } else {document.getElementById('turno').innerHTML='';}
        },2000);
    }
    recargarVentanaGato();

    function ganar(player)
    {
      con=1;
      if (player==0) {p='X'} else {p='O'}
      document.getElementById('x').innerHTML='<div class="alert alert-dark text-center" role="alert">El jugador '+p+' es el ganaor</div>';
      

      if (<?php echo $usuario; ?>==player) 
      {
        $.ajax({
          type: "POST",
          dataType: "json",
          url: '<?php echo base_url();?>Zd/fin',
          cache: false,
          data: "sala=<?php echo $sala;?>",
        });
      }

      $.ajax({
          type: "POST",
          dataType: "json",
          url: '<?php echo base_url();?>Zd/salir',
          cache: false,
          data: "sala=<?php echo $sala;?>",
        });
    }

  </script>

  <!-- Custom scripts for this template -->
</html>
