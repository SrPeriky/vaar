<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Jugador <?php echo $player; ?></title>

  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url(); ?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="<?php echo base_url(); ?>assets/css/sb-admin-2.min.css" rel="stylesheet">

   <!-- Custom styles for this page -->

   <style>
    .cuadrito{width:33%;height: 100px;border:solid 4px;float:left;font-size:25px;text-align:center;}
    #div_contenedor{width:25%;border:solid 0px;margin:auto;}
    li{font-size:28px;width:850px;margin-bottom:20px;}
  </style>

  <script src="<?php echo base_url(); ?>assets/gato/game.js"></script>
  <script src="<?php echo base_url(); ?>assets/gato/o.js"></script>
  <script src="<?php echo base_url(); ?>assets/gato/x.js"></script>
</head>